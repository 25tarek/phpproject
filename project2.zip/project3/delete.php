<?php 
include("connect.php");
if(isset($_GET['deleteId'])){
  $id=$_GET['deleteId'];

  $sql ="DELETE FROM `list` WHERE id=$id";
  $result= mysqli_query($conn,$sql);
  if($result){
    header('location: display.php');
  }
}
?>