<?php 
$conn=mysqli_connect("localhost","root","","crud1");
if(!$conn){
  die("error");
}

?>